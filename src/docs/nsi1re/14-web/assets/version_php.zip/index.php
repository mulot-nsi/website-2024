<!doctype html>

<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Titre de votre page</title>
</head>

<body>
<h1>Page d'accueil</h1>

<!-- Créez votre formulaire -->
</body>
</html>
