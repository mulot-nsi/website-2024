def generer_plateau():
    """
    Génère un plateau de jeu vide.
    Renvoie un tableau doublement indexé de taille 3x3 ne contenant que des zéros.
    """
    return [[]]


def case_plateau(valeur):
    """
    Convertit la valeur entière d'une case en son symbole d'affichage.

    Paramètre :
        valeur - La valeur de la case (0 pour vide, 1 pour X, 2 pour O)
    """
    return ''


def afficher_plateau(plateau):
    """
    Affiche le plateau de jeu dans la console.

    Paramètre :
        plateau - Le plateau de jeu sous forme d'un tableau doublement indexé.
    """
    affichage = ""
    for i_ligne in range(len(plateau)):
        # Construit la chaine d'affichage des pions d'une ligne du plateau.
        affichage += ' ' + '|'.join([case_plateau(case) for case in plateau[i_ligne]]) + '\n'

        # Construit la ligne horizontale de séparation.
        if i_ligne < 2:
            affichage += ('—' * 7) + '\n'

    print(affichage)


def demander_coup_joueur(joueur):
    """
    Demande au joueur de saisir son coup sous la forme '{ligne}{colonne}'.
    La saisie "11" signifie que le joueur joue dans la première case en haut à gauche du plateau de jeu (plateau[0][0]).

    La fonction renvoie un tuple des coordonnées (ligne, colonne) du coup choisi.
    La saisie "32" (ligne 3, colonne 2) entraine le renvoi du tuple (2, 1).

    Paramètre :
        joueur - Numéro du joueur (1 ou 2)
    """
    saisie = input("Joueur " + case_plateau(joueur) + " : ")
    return traiter_saisie_joueur(saisie)


def traiter_saisie_joueur(saisie):
    """
    Renvoie la convertion de la saisie du joueur un tuple des coordonnées (ligne, colonne).

    Paramètre :
        saisie - La chaîne saisie par le joueur (format : '{ligne}{colonne}')
    """
    return None


def jouer_coup_joueur(plateau, joueur, coup):
    """
    Place le symbole du joueur sur le plateau aux coordonnées spécifiées.

    Paramètres :
        plateau - Plateau de jeu sous forme d'un tableau doublement indexé
        joueur - Numéro du joueur
        coup - Tuple des coordonnées (ligne, colonne) où placer le symbole
    """
    pass


def tester_victoire(plateau, joueur):
    """
    Vérifie si le joueur spécifié a gagné la partie.
    Renvoie True si joueur a gagné, False sinon.

    Paramètres :
        plateau - Le plateau de jeu sous forme d'un tableau doublement indexé
        joueur - Le numéro du joueur à tester (1 ou 2)
    """
    return False


def tester_match_nul(plateau):
    """
    Vérifie si la partie est un match nul.
    Renvoie True si le match est nul, False sinon.

    Paramètre :
        plateau - Le plateau de jeu sous forme d'un tableau doublement indexé
    """
    return False


def afficher_victoire(joueur):
    """
    Affiche le message de victoire pour le joueur spécifié.

    Paramètre :
        joueur - Numéro du joueur gagnant (1 ou 2)
    """
    print("Le joueur " + case_plateau(joueur) + " a gagné !")


def afficher_nul():
    """ Affiche le message de match nul. """
    print("Match nul !")


def lancer_jeu():
    """ Lance une partie de morpion. """
    pass