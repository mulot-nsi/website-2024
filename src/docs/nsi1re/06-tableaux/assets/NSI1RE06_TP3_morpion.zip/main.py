import morpion

morpion.lancer_jeu()